def divide(a: float, b: float) -> float:
    return a / b