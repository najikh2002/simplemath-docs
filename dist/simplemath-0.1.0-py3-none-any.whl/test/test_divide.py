from simplemath import divide

def test_divide():
    result = divide(3, 2)
    assert result == 1.5