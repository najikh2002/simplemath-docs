from simplemath import multiply

def test_multiply():
    result = multiply(3, 2)
    assert result == 6