from simplemath import substract

def test_substract():
    result = substract(5, 2)
    assert result == 3
