from simplemath import add

def test_add():
    result = add(5, 2)
    assert result == 7